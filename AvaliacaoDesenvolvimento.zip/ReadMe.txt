O projeto necessita dos seguintes pacotes:

http://prntscr.com/iraeQ5khTLRA

Para utilização do projeto a base de dados deve ser criada da seguinte forma:

SGBD = PostgreSQL
Server = Localhost
Database = aula
User = postgres
Senha = postgres
porta = 5432