using $safeprojectname$.Modulos;
using Newtonsoft.Json;
using Npgsql;
using System.Text.Json.Nodes;
using static System.Net.WebClient;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        private NpgsqlConnection connection;
        IDictionary<int, int> IdUfs = new Dictionary<int, int>();
        public Form1()
        {
            InitializeComponent();
        }

        private static NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(@"Server=localhost;Port=5432;User ID=postgres;Password=postgres;Database=aula");
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            cbxSexo.SelectedIndex = 0;
            PreencherEstados();
            connection = GetConnection();
            connection.Open();
        }

        private void Salvar()
        {
            var sql = "";

            sql = "INSERT INTO public.cliente " +
                  "(nome, idade, sexo, cidade, estado)" +
                  "VALUES('" + tbxNome.Text + "', " + nudIdade.Value + ", " + cbxSexo.SelectedIndex + ", '" + cbxCidade.SelectedItem + "', '" + cbxEstado.SelectedItem + "'); ";

            try
            {
                using var cmd = new NpgsqlCommand(sql, this.connection);
                cmd.ExecuteNonQuery();
                LimparCampos();
            }
            catch (Exception ex)
            {
                if (ex.Message != "") MessageBox.Show("N�o foi possivel gravar os dados " + ex.Message);
            }
            
        }
        private void ValidarCampos()
        {
            if (tbxCodigo.Text == "")
            {
                tbxCodigo.Focus();
                MessageBox.Show("Preencha o campo Codigo");
            }
            else if (tbxNome.Text == "")
            {
                tbxNome.Focus();
                MessageBox.Show("Preencha o campo Nome");
            }
            else if (nudIdade.Value == 0)
            {
                nudIdade.Focus();
                MessageBox.Show("Preencha o campo Idade");
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            ValidarCampos();
            Salvar();
        }

        private void edtCodigo_Leave(object sender, EventArgs e)
        {
            ValidaPesquisa();
        }
        public bool ExisteCodigo(string codigoPessoa) {
            var sql = "";
            sql = "select 1 from cliente where codigo = " + codigoPessoa;

            NpgsqlConnection newConnection;

            newConnection = GetConnection();
            newConnection.Open();

            using var cmdMaxCodigo = new NpgsqlCommand(sql, newConnection);
            
            var existeCodigo = cmdMaxCodigo.ExecuteScalar();

            cmdMaxCodigo.Cancel();

            return existeCodigo != null;
        }
        private void ValidaPesquisa()
        {
            if (tbxCodigo.Text == "")
                tbxCodigo.Text = GetMaiorCodigo();
            else
            {

                if (ExisteCodigo(tbxCodigo.Text))
                {
                    NpgsqlConnection newConnection;

                    newConnection = GetConnection();
                    newConnection.Open();
                    using NpgsqlCommand cmdDados = new NpgsqlCommand("select * from cliente where codigo = " + tbxCodigo.Text, newConnection);

                    NpgsqlDataReader dados = cmdDados.ExecuteReader();

                    if (!dados.HasRows) {
                        return;
                    }
                    while (dados.Read())
                    {
                        tbxCodigo.Text = Convert.ToString(dados.GetInt16(0));
                        tbxNome.Text = dados.GetString(1);
                        nudIdade.Value = dados.GetInt16(2);
                        cbxSexo.SelectedIndex = dados.GetInt16(3);
                        cbxEstado.SelectedItem = dados.GetString(4);
                        PreencherMunicipios();
                        cbxCidade.SelectedItem = dados.GetString(5);
                    }
                }
            }

        }
        private void LimparCampos() {

            tbxCodigo.Clear();
            tbxNome.Clear();
            nudIdade.Value = 0;
            cbxSexo.SelectedIndex = 0;
            cbxEstado.SelectedIndex = 0;
            cbxCidade.SelectedItem = 0;

        }
        private string GetMaiorCodigo()
        {
            var sql = "SELECT max(codigo) from cliente ";

            using var cmd = new NpgsqlCommand(sql, this.connection);

            var maiorCodigo = cmd.ExecuteScalar();

            cmd.Cancel();
            if (maiorCodigo == DBNull.Value)
                return "1";
            else
                return Convert.ToString(Convert.ToInt32(maiorCodigo)+1);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (ExisteCodigo(tbxCodigo.Text)) {

                var sql = "";

                sql = "delete from cliente where codigo = " + tbxCodigo.Text;
                using var cmd = new NpgsqlCommand(sql, this.connection);
                cmd.ExecuteNonQuery();
            }
            LimparCampos();
        }

        public void PreencherEstados() {

            string urlGetEstados = "https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome";
            System.Net.WebClient webClient = new();

            string response = webClient.DownloadString(urlGetEstados);

            var jsonEstados = JsonConvert.DeserializeObject<List<Estado>>(response);


            for (int i=0;i<27; i++)
            {
                IdUfs.Add(i, jsonEstados[i].id);
                cbxEstado.Items.Add(jsonEstados[i].nome);
            }
            cbxEstado.SelectedIndex= 0;
        }
        private void PreencherMunicipios() {

            cbxCidade.Items.Clear();    
            cbxCidade.Enabled = true;

            string urlGetCidades = "";
            System.Net.WebClient webClient = new();
            int idEstado = 0;

            if (IdUfs.TryGetValue(cbxEstado.SelectedIndex, out idEstado))
            {
                urlGetCidades = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/" + idEstado + "/municipios";
            }

            string response = webClient.DownloadString(urlGetCidades);

            var jsonCidades = JsonConvert.DeserializeObject<List<Cidades>>(response);


            for (int i = 0; i < jsonCidades.Count; i++)
            {
                cbxCidade.Items.Add(jsonCidades[i].nome);
            }
            cbxCidade.SelectedIndex = 0;


        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            tbxCodigo.Text = GetMaiorCodigo();
        }

        private void cbxEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            PreencherMunicipios();
        }
    }
}