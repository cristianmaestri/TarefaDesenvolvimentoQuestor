﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modulos
{
    public class Cidades
    {
        public int id { get; set; }
        public string nome { get; set; }

    }
}
