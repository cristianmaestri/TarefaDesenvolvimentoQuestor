﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace $safeprojectname$.Modulos
{
    public class Estado
    {
            
        public int id { get; set; }
        public string sigla { get; set; }
        public string nome { get; set; }

    }
}

